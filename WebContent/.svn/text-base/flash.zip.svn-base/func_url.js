function GoUrl( goURL )
{
	//alert( goURL );
	switch( goURL )
	{
		
		case "home":
			location.href="/";
			break;

		case "sitemap":
			location.href="/";
			break;

		case "login":
			location.href="/";
			break;

		case "logout":
			location.href="/";
			break;



		case "m101":
			location.href="";
			break;
		
		case "m102":
			location.href="";
			break;
		
		case "m103":
			location.href="";
			break;
		
		case "m104":
			location.href="";
			break;
		
		case "m105":
			location.href="";
			break;


		
		case "m201":
			location.href="";
			break;
		
		case "m202":
			location.href="";
			break;

		case "m203":
			location.href="";
			break;
		
		case "m204":
			location.href="";
			break;

		case "m205":
			location.href="";
			break;
		
	
	
		case "info01":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=susu&sido_code=susu";
			break;
				
		case "info02":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=bsbs&sido_code=bsbs";
			break;
		
		case "info03":
	        location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=dgdg&sido_code=dgdg";
			break;
			
		case "info04":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=icic&sido_code=icic";
			break;

		case "info05":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=gjgj&sido_code=gjgj";
			break;	
		
		case "info06":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=djdj&sido_code=djdj";
			break;
		
		case "info07":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=usus&sido_code=usus";
			break;	
		
		case "info08":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=gggg&sido_code=gggg";
			break;
			
		case "info09":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=gwgw&sido_code=gwgw";
			break;

		case "info10":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=cbcb&sido_code=cbcb";
			break;	
		
		case "info11":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=cncn&sido_code=cncn";
			break;
		
		case "info12":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=jbjb&sido_code=jbjb";
			break;	
		
		case "info13":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=jnjn&sido_code=jnjn";
			break;

		case "info14":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=gbgb&sido_code=gbgb";
			break;	
		
		case "info15":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=gngn&sido_code=gngn";
			break;
		
		case "info16":
			location.href="../service/ServiceAction.do?cmd=CivilCenterGuide&area_code=jjjj&sido_code=jjjj";
			break;	
		
	}
}